import { createContext, ReactNode, useContext, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { LoginData, AuthResponse } from "@shared/schema";
import { apiRequest, queryClient } from "../lib/queryClient";
import { useToast } from "@/hooks/use-toast";

type AuthContextType = {
  token: string | null;
  user: AuthResponse['user'] | null;
  isLoading: boolean;
  error: Error | null;
  loginMutation: any;
  registerMutation: any;
  logout: () => void;
};

const AUTH_TOKEN_KEY = 'auth_token';

export const AuthContext = createContext<AuthContextType | null>(null);

export function AuthProvider({ children }: { children: ReactNode }) {
  const { toast } = useToast();

  // Initialize auth state from localStorage
  const savedToken = localStorage.getItem(AUTH_TOKEN_KEY);

  const {
    data: authData,
    error,
    isLoading,
    refetch
  } = useQuery<AuthResponse>({
    queryKey: ["/api/user"],
    enabled: !!savedToken,
  });

  const loginMutation = useMutation({
    mutationFn: async (credentials: LoginData) => {
      const res = await apiRequest("POST", "/api/login", credentials);
      return await res.json();
    },
    onSuccess: (data: AuthResponse) => {
      localStorage.setItem(AUTH_TOKEN_KEY, data.token);
      queryClient.setQueryData(["/api/user"], data);
      toast({
        title: "Login successful",
        description: "Welcome back!",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Login failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const registerMutation = useMutation({
    mutationFn: async (credentials: LoginData) => {
      const res = await apiRequest("POST", "/api/register", credentials);
      return await res.json();
    },
    onSuccess: (data: AuthResponse) => {
      localStorage.setItem(AUTH_TOKEN_KEY, data.token);
      queryClient.setQueryData(["/api/user"], data);
      toast({
        title: "Registration successful",
        description: "Welcome to License Key Store!",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Registration failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const logout = () => {
    localStorage.removeItem(AUTH_TOKEN_KEY);
    queryClient.setQueryData(["/api/user"], null);
    queryClient.clear();
  };

  // Update the auth header for all requests
  useEffect(() => {
    if (savedToken) {
      const oldFetch = window.fetch;
      window.fetch = async function (...args) {
        if (typeof args[0] === 'string' && args[0].startsWith('/api/')) {
          const options = args[1] || {};
          const headers = {
            ...options.headers,
            'Authorization': `Bearer ${savedToken}`,
          };
          args[1] = { ...options, headers };
        }
        return oldFetch.apply(window, args as any);
      };
    }
  }, [savedToken]);

  return (
    <AuthContext.Provider
      value={{
        token: savedToken,
        user: authData?.user ?? null,
        isLoading,
        error,
        loginMutation,
        registerMutation,
        logout,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error("useAuth must be used within an AuthProvider");
  }
  return context;
}