import type { Express } from "express";
import { createServer, type Server } from "http";
import { setupAuth } from "./auth";

export async function registerRoutes(app: Express): Promise<Server> {
  const httpServer = createServer(app);

  // Authentication routes
  app.post("/api/login", async (req, res) => {
    try {
      const response = await fetch("http://admin.indiansofa.com/api/user/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(req.body),
      });

      if (!response.ok) {
        const error = await response.text();
        console.error("Login error:", error);
        return res.status(response.status).json({ error });
      }

      const data = await response.json();
      res.json(data);
    } catch (error: any) {
      console.error("Login error:", error);
      res.status(500).json({ error: error.message });
    }
  });

  app.post("/api/register", async (req, res) => {
    try {
      const response = await fetch("http://admin.indiansofa.com/api/user/register", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(req.body),
      });

      if (!response.ok) {
        const error = await response.text();
        console.error("Registration error:", error);
        return res.status(response.status).json({ error });
      }

      const data = await response.json();
      res.json(data);
    } catch (error: any) {
      console.error("Registration error:", error);
      res.status(500).json({ error: error.message });
    }
  });

  // Product routes
  app.get("/api/products", async (req, res) => {
    try {
      const response = await fetch("http://admin.indiansofa.com/api/products");
      if (!response.ok) throw new Error("Failed to fetch products");
      const data = await response.json();
      res.json(data);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch products" });
    }
  });

  // Category routes (from original code)
  app.get("/api/categories", async (req, res) => {
    try {
      const response = await fetch("http://admin.indiansofa.com/api/categories");
      if (!response.ok) throw new Error("Failed to fetch categories");
      const data = await response.json();
      res.json(data);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch categories" });
    }
  });


  // Cart endpoints (updated from edited code)
  app.post("/api/cart/add", async (req, res) => {
    const token = req.headers.authorization;
    if (!token) return res.status(401).json({ error: "No token provided" });

    try {
      const response = await fetch("http://admin.indiansofa.com/api/cart/addToCart", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Authorization": token
        },
        body: JSON.stringify({
          product_id: req.body.product_id.toString(),
          quantity: parseInt(req.body.quantity) || 1
        }),
      });

      if (!response.ok) {
        const error = await response.text();
        console.error("Cart add error:", error);
        throw new Error(`Failed to add to cart: ${error}`);
      }

      const data = await response.json();
      res.json(data);
    } catch (error: any) {
      console.error("Cart add error:", error);
      res.status(500).json({ error: error.message });
    }
  });

  app.get("/api/cart", async (req, res) => {
    const token = req.headers.authorization;
    if (!token) return res.status(401).json({ error: "No token provided" });
    try {
      const response = await fetch("http://admin.indiansofa.com/api/cart/viewCart", {
        headers: {
          "Authorization": token
        }
      });
      if (!response.ok) throw new Error("Failed to fetch cart");
      const data = await response.json();
      res.json(data);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch cart" });
    }
  });

  app.delete("/api/cart/:id", async (req, res) => {
    const token = req.headers.authorization;
    if (!token) return res.status(401).json({ error: "No token provided" });
    try {
      const response = await fetch(`http://admin.indiansofa.com/api/cart/removeCart/${req.params.id}`, {
        method: "DELETE",
        headers: {
          "Authorization": token
        }
      });
      if (!response.ok) throw new Error("Failed to remove from cart");
      const data = await response.json();
      res.json(data);
    } catch (error) {
      res.status(500).json({ error: "Failed to remove from cart" });
    }
  });

  setupAuth(app); // from original code

  return httpServer;
}